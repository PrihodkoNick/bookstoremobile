// import React from 'react';

// import Home from './Home';
// import Login from '../Login/Login';
// import Register from '../Register/Register';
// import SideBar from '../../components/SideBar/SideBar';

// const HomeScreenRouter = DrawerNavigator(
//   {
//     Home: {screen: Home},
//     Login: {screen: Login},
//     Register: {screen: Register},
//   },
//   {
//     contentComponent: props => <SideBar {...props} />,
//   }
// );

// export default HomeScreenRouter;
