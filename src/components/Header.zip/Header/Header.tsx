import React from 'react';
import {Container, Header, Text, Left, Body, Button, Title} from 'native-base';

const HeaderApp = ({navigation}) => {
  return (
    <Container>
      <Header>
        <Left>
          <Button
            transparent
            onPress={() => navigation.navigate("DrawerOpen")}
          >
            <Text>Меню</Text>
          </Button>
        </Left>
        <Body>
          <Title>Book Store</Title>
        </Body>
      </Header>
    </Container>
  );
};

export default HeaderApp;